```uml
@startuml
start
:体力 = 10;
if(体力 <= 20 )then(ture)
:宿屋に泊まる;
else(false)
:頑張ってレベル上げる;
endif

end
@enduml
```
