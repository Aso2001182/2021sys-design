```uml
@startuml
Alice -> Bob: Request
Bob -> Alice: Response
@enduml
```
